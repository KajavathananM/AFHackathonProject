'use strict';

import React from 'react';
import {render} from 'react-dom';

import AppContainerOne from './Containers/AppContainerOne';
import AppContainerTwo from './Containers/AppContainerTwo';
import AppContainerThree from './Containers/AppContainerThree';

let DEFAULT_TITLE="Welcome, Please select your desired vacation type to view what's happening now...";
let EVENT_VIEWED_USER="Thank You for checking out...";

var marq = document.getElementById('marq');
var btnClick = document.getElementById('Btn')
marq.innerText=DEFAULT_TITLE;

render(<AppContainerOne/>,document.getElementById('app'));
render(<AppContainerTwo/>,document.getElementById('apptwo'));
render(<AppContainerThree/>,document.getElementById('appthree'));

function setViewed(){
    btnClick=true;
}

if(btnClick.onclick){
    marq.innerText=EVENT_VIEWED_USER;
}