'use strict';

import React, {Component} from 'react';
export default class AppContainerOne extends Component{
    render() {
        return(
            <div>
                <h2>Relaxation</h2>
                <button onClick="setViewed()" className="button"><span>View</span></button>
            </div>
        );
    }
}

