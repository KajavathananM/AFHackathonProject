'use strict';

import React, {Component} from 'react';
export default class AppContainerThree extends Component{
    render() {
        return(
            <div>
                <h2>Religious places and ancient ruins</h2>
                <button onClick="setViewed()" className="button"><span>View</span></button>
            </div>
        );
    }
}