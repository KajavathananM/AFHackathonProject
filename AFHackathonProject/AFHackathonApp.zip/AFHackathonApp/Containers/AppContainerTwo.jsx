'use strict';

import React, {Component} from 'react';
export default class AppContainerTwo extends Component{
    render() {
        return(
            <div>
                <h2>Party and dance</h2>
                <button onClick="setViewed()" className="button"><span>View</span></button>
            </div>
        );
    }
}